function [F0, isVoiced] = findF0(Fs, acf)
    % Theo luận văn, tác giả đã thực nghiệm khảo sát ngưỡng với các mốc
    % 30%, 50%, 70% so với biên độ cực đại toàn cục
    % Nhận thấy 30% là ngưỡng cho quyết định tốt nhất
    threshold = 0.3;
    
    % Giọng nam có F0 từ 70Hz->250Hz
    % Giọng nữ có F0 từ 150Hz->400Hz
    FMin = 70; FMax = 400;
    peakIndex = [];
    peakValue = [];
    count = 1;
    % loai phan tu dau va cuoi
    for i = 2 : length(acf) - 1 
        if(acf(i) > acf(i - 1) && acf(i) > acf(i + 1))
            peakIndex(count) = i;
            peakValue(count) = acf(i);
            count = count + 1;
        end
    end
    % gia tri cua local max, chi muc cua local max
    % vi tri cua dinh cuc bo trong tat ca cac dinh
    [local_max, max_index] = max(peakValue);
    % vi tri cua peak trong frame
    lag = peakIndex(max_index); 
    
    % Cong thuc tim F0
    F0 = Fs / lag;  
    
    if(local_max > threshold && F0 > FMin && F0 < FMax) 
        isVoiced = true;
    else
        isVoiced = false;
    end
end