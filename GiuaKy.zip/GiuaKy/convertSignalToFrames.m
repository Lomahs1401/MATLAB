function [frames, totalFrames] = convertSignalToFrames(speechSignal, Fs, frameDuration)
    % so mau cua 1 frame. Lam tron duoi
    frameSize = round(frameDuration * Fs); 
    % tong so frame co the chia tu data (lam tron duoi)
    totalFrames = floor(length(speechSignal) / frameSize); 
    
    %% Duyet vong lap de bat dau chia khung frame
    temp = 1;
    frames = [];
    for i = 1 : totalFrames
        % Vong lap 1: duyet tu 1->400 mau c?a khung 1
        % Vong lap 2: 401->800 mau tin hieu
        % Tiep tuc lap den vong lap thu 'totalFrames'
        frames(i, :) = speechSignal(temp : temp + frameSize - 1);
        % Tinh vi tri bat dau cua khung tiep theo
        temp = temp + frameSize;
    end
end